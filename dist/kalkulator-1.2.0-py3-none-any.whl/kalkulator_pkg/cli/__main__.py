from .app import main_entry
import sys

if __name__ == "__main__":
    sys.exit(main_entry())
