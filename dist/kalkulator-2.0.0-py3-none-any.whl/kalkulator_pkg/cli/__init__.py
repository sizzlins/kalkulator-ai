from .app import main_entry

__all__ = ["main_entry"]
